import React from "react";
import "./number.css";

function NumberInput() {
  return (
    <div>
      <input type="text" className="square" />
    </div>
  );
}

export default NumberInput;
